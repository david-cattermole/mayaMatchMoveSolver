<!-- SPDX-License-Identifier: CC-BY-4.0 -->
<!-- Copyright Contributors to the OpenColorIO Project. -->

DATE

Host: NAME (Michael Dolan?)

Secretary: NAME

Attendees:
  * [ ] Mark Boorer (_TSC_) - Industrial Light & Magic
  * [ ] Mei Chu (_TSC_) - Sony Pictures Imageworks
  * [ ] Sean Cooper (_TSC ACES TAC Rep_) - ARRI
  * [ ] Michael Dolan (_TSC Chair_) - Epic Games
  * [ ] Patrick Hodoul (_TSC_) - Autodesk
  * [ ] John Mertic - Academy Software Foundation / Linux Foundation
  * [ ] Carol Payne (_TSC_) - Netflix
  * [ ] Mark Titchener (_TSC_) - Foundry
  * [ ] Carl Rand (_TSC_) - Weta Digital
  * [ ] Doug Walker (_TSC Chief Architect_) - Autodesk
  * [ ] Kevin Wheatley (_TSC_) - Framestore
  * ...others...

Apologies:
  NONE

# **OCIO TSC Meeting Notes**

* Topic 1
    - info
    - info

* Topic 2
    - info
    - info

* Items for next TSC meeting agenda:
    - xxx
