<!-- SPDX-License-Identifier: CC-BY-4.0 -->
<!-- Copyright Contributors to the OpenColorIO project. -->

# OpenColorIO Committers

The current OpenColorIO Committers are:

| Name           | GitHub ID |
| -------------- | -----------------
| Malcolm Humphreys | @malcolmhumphreys |
| Jeremy Selan | @jeremyselan |
| Steve Lavietes | @stevelavietes |
| Robert Molholm | @rmolholm |
| Michael Dolan | @michdolan |
| Mark Boorer | @Shootfast |
| Matthias Scharfenberg | @Tristimulus |
| Sean Cooper | @scoopxyz
| Patrick Hodoul | @hodoulp
| Cottalango Leon | @loorthu
| Doug Walker | @doug-walker |
| Kevin Wheatley | @KevinJW |
| Rémi Achard | @remia |
| Cédrik Fuoco | @cedrik-fuoco-adsk |
