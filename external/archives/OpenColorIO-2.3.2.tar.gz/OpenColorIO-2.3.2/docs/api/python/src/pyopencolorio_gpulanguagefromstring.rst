..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. autofunction:: PyOpenColorIO.GpuLanguageFromString
