..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. autoclass:: PyOpenColorIO.UniformDataType
   :members:
   :undoc-members:
   :exclude-members: name

   .. py:method:: name() -> str
      :property:
