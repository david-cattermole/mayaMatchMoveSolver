..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

ASWF
====

.. toctree::
   :caption: ASWF

   license
   charter
   cla_dco
   aswf_docker
