..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. _concepts_overview:

Overview
========

.. include:: introduction.rst

.. include:: internal_architecture.rst

.. include:: glossary.rst
