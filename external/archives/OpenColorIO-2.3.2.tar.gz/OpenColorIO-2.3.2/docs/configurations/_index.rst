..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

Configurations
==============

.. _configurations:

.. toctree::
   :caption: Configurations

   aces_studio
   aces_cg
   ocio_v2_demo
   aces_1.0.3
   spi_anim
   spi_vfx
   nuke_default
