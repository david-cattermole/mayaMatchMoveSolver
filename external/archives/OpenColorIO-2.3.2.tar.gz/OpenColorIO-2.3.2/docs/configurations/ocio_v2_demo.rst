..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. _ocio-v2_demo:

ocio-v2_demo
============

Note: this is not intended to be a complete production-ready config, its purpose
is to introduce many of the new features in OCIO v2.

Due to the limitations of the web template, it may be easier for you to read this
config in a text editor.  The config file is located 
`here. <https://github.com/AcademySoftwareFoundation/OpenColorIO/tree/main/docs/configurations/ocio-v2_demo.ocio>`_ 


.. literalinclude:: ocio-v2_demo.ocio
   :language: yaml
