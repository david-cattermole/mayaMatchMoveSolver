..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

Guides
======

.. toctree::
   :caption: Guides

   using_ocio/using_ocio
   authoring/authoring
   developing/developing
   contributing/contributing
