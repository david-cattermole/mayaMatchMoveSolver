..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. TODO: To be authored by Patrick Hodoul

.. _architectural-notes:

Architectural notes
===================

Coming soon...
