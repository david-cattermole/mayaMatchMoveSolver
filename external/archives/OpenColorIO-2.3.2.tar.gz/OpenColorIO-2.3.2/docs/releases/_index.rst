..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. _upgrading_to_v2:

Releases
========

.. toctree::
   :caption: Upgrading to v2

   ocio_2_3
   ocio_2_2
   ocio_2_1
   ocio_2_0
