// This file is part of the Lens Distortion Plugin Kit
// Software is provided "as is" - no warranties implied.
// (C) 2011 - 2022,  Science-D-Visions. Current version: 2.8

#pragma once

#include <ldpk/ldpk_ldp_builtin.h>
#include <ldpk/ldpk_vec2d.h>

//! @file tde4_ldp_radial_fisheye_normalized_base.h
//! @brief Base class for fisheye toymodels with normalization.

template <class VEC2,class MAT2>
class tde4_ldp_radial_fisheye_normalized_base:public ldpk::ldp_builtin<VEC2,MAT2>
	{
private:
	typedef VEC2 vec2_type;
	typedef MAT2 mat2_type;
	typedef ldpk::ldp_builtin<VEC2,MAT2> base_type;

// This function is meant to determine the valid domain of undistort().
// On one hand we will know if the elongation leaves the domain given
// by the projection, as this is encode in the return value. On the other
// hand we can also study the behaviour of the mapped undistorted elongation.
// If it starts flipping back, we have left the valid domain.
	bool undistort_dn(double r_ed_dist_dn,double &r_plain_undist_dn)
		{
// The literature commonly says, undistorting should be done
// before applying the remapping. Usually it's applied to
// elongation angle theta = r/f. That's what we do here.
// theta = r/f is the equidistant projection, so here we have g o F^-1.
// In the toymodel we don't have distortion, but this is the point
// where we introduce normalization, todo.
		double r_ed_undist_dn = r_ed_dist_dn;
// Remap equidistant to gnomonic
		if(!remap_fe2plain(r_ed_undist_dn,r_plain_undist_dn))
			{ return false; }
		return true;
		}
protected:
	double _r_clip_factor;
// Largest radius for which undistort_dn() is still well-defined.
	double _r_ed_dn_domain;
// The domain radius mapped to undistorted. We will try
// to build a simple bounding box from this.
	double _r_plain_dn_domain;
// Focal length in dn-coordinates.
	double _fl_dn;
// Normalization factor, so that the four corners are invariant.
	double _normalization;

//! @brief Returns false, because there are no model specific parameters.
	bool decypher(const char* name,int& i)
		{
		return false;
		}
	bool initializeParameters()
		{
		typedef base_type bt;
		bt::check_builtin_parameters();
// Focal length in dn-coordinates.
		_fl_dn = bt::fl_cm() / bt::r_fb_cm();
// Normalization factor.
		remap_fe2plain(1.0,_normalization);

// We do a simple brute force scan per pass, but refine the search interval
// after each pass. Precision should be around 1e-5 afterwards.
// Not quite sure which value makes sense for radius_b.
// Without any distortion, the result r/f for stereographic is always 2.
// For othographic we get 1, for equisolid sqrt(2) and for equidistant pi/2.
		double radius_a = 0.0;
		double radius_b = M_PI * _fl_dn;
// At most n samples for each pass.
		int n = 50;
// A few passes
		for(int i_pass = 0;i_pass < 5;++i_pass)
			{
			double r_ed_dist_dn_prev = -1.0;
			double r_plain_undist_dn_prev = -1.0;
//std::cout << "radius_a / _fl_dn, radius_b / _fl_dn:" << radius_a / _fl_dn << " " << radius_b / _fl_dn << std::endl;
// We initialize the domain with the largest radius possible.
// In practice, the loop will terminate prior to reaching n,
// because at some point undistort_dn() wil return false,
// so this most likely is not relevant, but we want to make
// sure that _r_ed_dn_domain has some well-defined value.
			_r_ed_dn_domain = radius_b;
			double r_ed_dist_dn;
			for(int i = 0;i <= n;++i)
				{
// Normalized iterator.
				double q = double(i) / n;
// Scan r_ed_dist_dn from radius_a to radius_b, inclusive.
				r_ed_dist_dn = radius_a * (1.0 - q) + radius_b * q;
				double r_plain_undist_dn;
				if(!undistort_dn(r_ed_dist_dn,r_plain_undist_dn))
					{
// undistort fails, so we use domain radius and mapped radius from the previous round.
					_r_ed_dn_domain = r_ed_dist_dn_prev;
					_r_plain_dn_domain = r_plain_undist_dn_prev;
					break;
					}
// Found a turning point? We are looking for the point where the Jacobian degenerates,
// but this criterions is faster and simpler than evaluating the Jacobian.
				if(r_plain_undist_dn <= r_plain_undist_dn_prev)
					{
// The last known radius for which undistort_dn() was well-defined.
					_r_ed_dn_domain = r_ed_dist_dn_prev;
					_r_plain_dn_domain = r_plain_undist_dn_prev;
					break;
					}
// r_ed_dist_dn has successfully been mapped into r_plain_undist_dn.
// Our current radii become the previous radii for the next round.
				r_ed_dist_dn_prev = r_ed_dist_dn;
				r_plain_undist_dn_prev = r_plain_undist_dn;
// And we can extend our domain.
				_r_ed_dn_domain = r_ed_dist_dn;
				_r_plain_dn_domain = r_plain_undist_dn;
				}
// Refine search interval. radius_a is always in the valid domain.
			radius_a = r_ed_dist_dn_prev;
			radius_b = r_ed_dist_dn;
//std::cout << "r_domain / _fl_dn: " << _r_ed_dn_domain / _fl_dn << std::endl;
			}
		return true;
		}
//! @brief This toymodel does not have model specific parameters.
	bool getNumParameters(int& n)
		{
		n = 0;
		return true;
		}
//! @brief This toymodel does not have model specific parameters.
	bool getParameterName(int i,char* identifier)
		{
		return false;
		}
	bool setParameterValue(const char *identifier,double v)
		{
		typedef base_type bt;
		int i;
// Does the base class know the parameter?
		if(bt::set_builtin_parameter_value(identifier,v))
			{ return true; }
		if(!decypher(identifier,i))
			{ return false; }
		return true;
		}
	void getBoundingBoxUndistort(double xa_in,double ya_in,double xb_in,double yb_in,double& xa_out,double& ya_out,double& xb_out,double& yb_out,int nx,int ny)
		{
		typedef base_type bt;
// _r_plain_dn_domain represents the radius of the undistorted image in dn-coordinates.
// We form a square and use its corners as the bounding box for the undistorted image.
//		vec2_type p00_dn = vec2_type(-_r_plain_dn_domain,-_r_plain_dn_domain);
//		vec2_type p11_dn = vec2_type( _r_plain_dn_domain, _r_plain_dn_domain);

//		vec2_type p00_unit = bt::map_dn_to_unit(p00_dn);
//		vec2_type p11_unit = bt::map_dn_to_unit(p11_dn);

//		xa_out = p00_unit[0];
//		ya_out = p00_unit[1];
//		xb_out = p11_unit[0];
//		yb_out = p11_unit[1];

		xa_out = 0.0;
		ya_out = 0.0;
		xb_out = 1.0;
		yb_out = 1.0;

//		std::cout << "getBoundingBoxUndistort: " << xa_out << " " << ya_out << " " << xb_out << " " << yb_out << std::endl;
		}
	void getBoundingBoxDistort(double xa_in,double ya_in,double xb_in,double yb_in,double& xa_out,double& ya_out,double& xb_out,double& yb_out,int nx,int ny)
		{
		typedef base_type bt;

// _r_ed_dn_domain is the radius of the valid domain of undistort() in dn-coordinates.
// We form a square and use its corners as the bounding box for the distorted image.
//		vec2_type p00_dn = vec2_type(-_r_ed_dn_domain,-_r_ed_dn_domain);
//		vec2_type p11_dn = vec2_type( _r_ed_dn_domain, _r_ed_dn_domain);

//		vec2_type p00_unit = bt::map_dn_to_unit(p00_dn);
//		vec2_type p11_unit = bt::map_dn_to_unit(p11_dn);

//		xa_out = p00_unit[0];
//		ya_out = p00_unit[1];
//		xb_out = p11_unit[0];
//		yb_out = p11_unit[1];

		xa_out = 0.0;
		ya_out = 0.0;
		xb_out = 1.0;
		yb_out = 1.0;

//		std::cout << "getBoundingBoxDistort: " << xa_out << " " << ya_out << " " << xb_out << " " << yb_out << std::endl;
		}


	virtual bool remap_fe2plain(double r_ed_dn,double& r_plain_dn) = 0;
	virtual bool remap_plain2fe(double r_plain_dn,double& r_ed_dn) = 0;
// Overwriting tde4_ldp_common
	bool undistort(double x0,double y0,double &x1,double &y1)
		{
		typedef base_type bt;

		vec2_type p_ed_dist_dn = bt::map_unit_to_dn(vec2_type(x0,y0));

// Distance from origin in dn-coordinates
		double r_ed_dist_dn = norm2(p_ed_dist_dn);
// We have determined the domain of undistort() in initializeParameters().
		if(r_ed_dist_dn > _r_ed_dn_domain)
			{ return false; }
// The literature commonly says, undistorting should be done
// before applying the remapping. Usually it's applied to
// elongation angle theta = r/f. That's what we do here.
// theta = r/f is the equidistant projection, so here we have g o F^-1.
		double r_ed_undist_dn = r_ed_dist_dn;

// Remap equidistant to gnomonic
		double r_plain_undist_dn_unnormalized;
		if(!remap_fe2plain(r_ed_undist_dn,r_plain_undist_dn_unnormalized))
			{ return false; }

// Normalize
		double r_plain_undist_dn = r_plain_undist_dn_unnormalized / _normalization;


// Calc undistorted point from undistorted radius
		vec2_type p_plain_undist_dn;
		if(dotsq(p_ed_dist_dn) == 0.0)
			{ p_plain_undist_dn = vec2_type(0,0); }
		else
			{ p_plain_undist_dn = r_plain_undist_dn * unit(p_ed_dist_dn); }
// Map back to unit coordinates		
		vec2_type p_plain_undist_unit = bt::map_dn_to_unit(p_plain_undist_dn);
		x1 = p_plain_undist_unit[0];
		y1 = p_plain_undist_unit[1];
		return true;
		}
	bool distort(double x0,double y0,double &x1,double &y1)
		{
		typedef base_type bt;

		vec2_type p_plain_undis_dn = bt::map_unit_to_dn(vec2_type(x0,y0));
// Distance from origin in dn-coordinates
		double r_ed_undis_dn,r_plain_undis_dn = norm2(p_plain_undis_dn);
// We have determined the domain of undistort() in initializeParameters().
// Using the undistorted radius, we can formulate a criterion for distort().
		if(r_plain_undis_dn > _r_plain_dn_domain)
			{ return false; }

// Remap gnomonic to equidistant with denormalization prepended.
		if(!remap_plain2fe(r_plain_undis_dn * _normalization,r_ed_undis_dn))
			{ return false; }

// No distortion, toymodel.
		double r_ed_dis_dn = r_ed_undis_dn;
// Calc distorted point from distorted radius
		vec2_type p_ed_dis_dn;
		if(dotsq(p_plain_undis_dn) == 0.0)
			{ p_ed_dis_dn = vec2_type(0,0); }
		else
			{ p_ed_dis_dn = r_ed_dis_dn * unit(p_plain_undis_dn); }
// Map back to unit coordinates		
		vec2_type p_ed_dis_unit = bt::map_dn_to_unit(p_ed_dis_dn);
		x1 = p_ed_dis_unit[0];
		y1 = p_ed_dis_unit[1];
		return true;
		}
public:
// Mutex initialized and destroyed in baseclass.
	tde4_ldp_radial_fisheye_normalized_base():_r_clip_factor(50.0),_r_ed_dn_domain(0.0)
		{ }
	~tde4_ldp_radial_fisheye_normalized_base()
		{ }
	double r_clip_factor() const
		{ return _r_clip_factor; }
	void r_clip_factor(double f)
		{ _r_clip_factor = f; }
	virtual bool getModelName(char *name) = 0;
	bool getParameterType(const char* identifier,tde4_ldp_ptype& ptype)
		{
		typedef base_type bt;
		int i;
		if(bt::get_builtin_parameter_type(identifier,ptype)) return true;
		if(!decypher(identifier,i)) return false;
		ptype = TDE4_LDP_ADJUSTABLE_DOUBLE;
		return true;
		}
	bool getParameterDefaultValue(const char* identifier,double& v)
		{
		typedef base_type bt;
		int i;
		if(!decypher(identifier,i)) return false;
		return true;
		}
	bool getParameterRange(const char* identifier,double& a,double& b)
		{
		typedef base_type bt;
		int i;
		if(!decypher(identifier,i)) return false;
		return true;
		}
	};
